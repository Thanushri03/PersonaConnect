
package personaconnect;
import java.io.IOException;
import java.net.*;

public class Client {
    private static final int BUFFER_SIZE = 1024;
    private static final int PORT = 12345;

    private DatagramSocket socket;

    public void start() {
        try {
            socket = new DatagramSocket();

            Thread receiverThread = new Thread(new ReceiverThread());
            receiverThread.start();

            while (true) {
                String message = System.console().readLine();
                byte[] buffer = message.getBytes();

                InetAddress serverAddress = InetAddress.getByName("localhost");
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length, serverAddress, PORT);

                socket.send(packet);
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        }
    }

    private class ReceiverThread implements Runnable {
        @Override
        public void run() {
            try {
                while (true) {
                    byte[] buffer = new byte[BUFFER_SIZE];
                    DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                    socket.receive(packet);

                    String message = new String(packet.getData(), 0, packet.getLength());
                    System.out.println("Received: " + message);
                }
            } catch (SocketException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        Client client = new Client();
        client.start();
    }
}

