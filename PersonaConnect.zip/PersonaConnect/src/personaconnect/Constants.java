package personaconnect;
public class Constants {
    public static final String IP="225.4.5.6";
    public static final int PORT = 5554;
    public static final int BUFFER_SIZE=1024;
    public static final int IP_HEADER_DESTINATION_ADDRESS_OFFSET = 16;
}