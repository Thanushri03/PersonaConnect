package personaconnect;
import java.sql.*;
import java.util.*;
public class MyConnection {
    public static Connection getConnection(){
        Connection con = null;
        try{
            con =DriverManager.getConnection("jdbc:mysql:///personaconnect","root","Aishu*123");
        }catch(Exception ex){
            System.out.println("Conn :"+ex.toString());
        }
        return con;
        
    }
}
