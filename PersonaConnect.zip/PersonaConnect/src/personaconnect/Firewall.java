
package personaconnect;
import java.util.ArrayList;
import java.util.List;

public class Firewall {
    private List<String> blockedIPs;

    public Firewall() {
        blockedIPs = new ArrayList<>();
    }

    public void blockIP(String ipAddress) {
        blockedIPs.add(ipAddress);
    }

    public boolean isIPBlocked(String ipAddress) {
        return blockedIPs.contains(ipAddress);
    }
}
