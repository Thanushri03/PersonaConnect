package personaconnect;

import java.io.IOException;
import java.net.*;

public class Server {
    private static final int BUFFER_SIZE = 1024;
    private static final int PORT = 12345;

    private DatagramSocket socket;
    private boolean running;
    private Firewall firewall;

    public Server() {
        firewall = new Firewall();
    }

    public void start() {
        try {
            socket = new DatagramSocket(PORT);
            running = true;
            System.out.println("Server started on port " + PORT);

            while (running) {
                byte[] buffer = new byte[BUFFER_SIZE];
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                socket.receive(packet);

                String message = new String(packet.getData(), 0, packet.getLength());
                String ipAddress = packet.getAddress().getHostAddress();
                int clientPort = packet.getPort();

                if (firewall.isIPBlocked(ipAddress)) {
                    System.out.println("Blocked message from " + ipAddress);
                    continue;
                }

                System.out.println("Received message from " + ipAddress + ": " + message);

                // Broadcast message to all clients
                broadcast(message, ipAddress, clientPort);
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        }
    }

    private void broadcast(String message, String senderIPAddress, int senderPort) throws IOException {
        byte[] buffer = message.getBytes();

        InetAddress broadcastAddress = InetAddress.getByName("255.255.255.255");
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length, broadcastAddress, PORT);

        socket.send(packet);
        System.out.println("Broadcast message: " + message);
    }

    public void stop() {
        running = false;
    }

    public void blockIP(String ipAddress) {
        firewall.blockIP(ipAddress);
        System.out.println("IP address blocked: " + ipAddress);
    }

    public static void main(String[] args) {
        Server server = new Server();
        server.blockIP("192.168.0.2"); // Example: Block a specific IP address
        server.start();
    }
}
