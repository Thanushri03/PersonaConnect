package personaconnect;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.*;
import java.util.List;
import java.util.ArrayList;

public class PersonaConnectClient extends JFrame {
    private MulticastSocket socket;
    private byte[] buffer;
    private DatagramPacket packet;
    private InetAddress ip;
    private JLabel questionLabel;
    private JButton optionButtonA;
    private JButton optionButtonB;
    private JButton backButton;
    private JButton nextButton;
    private JButton closeButton;
    public List<String> userAnswers = new ArrayList<>();
   
  

    public static void main(String[] args) {
        PersonaConnectClient client = new PersonaConnectClient();
        client.initializeVariable();
        client.createAndShowGUI();
        client.connecting();
       client.categorizaton();
    }

    public void initializeVariable() {
        try {
            socket = new MulticastSocket(Constants.PORT);
            ip = InetAddress.getByName(Constants.IP);
            buffer = new byte[Constants.BUFFER_SIZE];
        } catch (SocketException ex) {
            log("initializeVariable: " + ex.toString());
        } catch (IOException ex) {
            log("initializeVariable: " + ex.toString());
        }
    }

    public void joinGroup() {
        try {
            socket.joinGroup(ip);
            log("Client Running...");
        } catch (IOException ex) {
            log("joinGroup: " + ex.toString());
        }
    }
public void connecting() {
    joinGroup();
    // Start by displaying the first question
    showNextQuestion();

    optionButtonA.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            processResponse("a");
            checkCategories();
        }
    });

    optionButtonB.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            processResponse("b");
            checkCategories();
        }
    });

    nextButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            showNextQuestion();
        }
    });

closeButton.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
      closeConnection();
        
    }
});

backButton.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
      returnToMenuForm();
        
    }
});
        }
public void checkCategories() {
    if (userAnswers.size() >= 4) {
        categorizaton();
    }
}

public void categorizaton() {
    String a1, a2, a3, a4;
    String answer1 = userAnswers.get(0);
    String answer2 = userAnswers.get(1);
    String answer3 = userAnswers.get(2);
    String answer4 = userAnswers.get(3);
    
    if (answer1.equals("a")) {
        a1 = "E";
    } else {
        a1 = "I";
    }
    
    if (answer2.equals("a")) {
        a2 = "S";
    } else {
        a2 = "N";
    }
    
    if (answer3.equals("a")) {
        a3 = "T";
    } else {
        a3 = "F";
    }
    
    if (answer4.equals("a")) {
        a4 = "J";
    } else {
        a4 = "P";
    }
    String personality=a1 + a2 + a3 + a4;
    System.out.println("Personality type: " + personality);
    JOptionPane.showMessageDialog(this,  personality,"Personality type: " , JOptionPane.INFORMATION_MESSAGE);
  }


    public void showNextQuestion() {
        String question = recieveData();
        questionLabel.setText(question);

        // Reset the options buttons
        optionButtonA.setEnabled(true);
        optionButtonB.setEnabled(true);
    }

public void processResponse(String response) {
    log("Answers: " + response);

    userAnswers.add(response);
    optionButtonA.setEnabled(false);
    optionButtonB.setEnabled(false);
   
    // Display the answers in the JFrame
    StringBuilder answerText = new StringBuilder("<html><body>");
    for (String answer : userAnswers) {
        answerText.append(answer).append("<br>");
    }
    answerText.append("</body></html>");
   System.out.println("User Answers:");
for (String answer : userAnswers) {
    System.out.println(answer);
}

    JOptionPane.showMessageDialog(this, answerText.toString(), "Your Answers", JOptionPane.INFORMATION_MESSAGE);
    
}


    public void closeConnection() {
        log("Closing connection...");
        socket.close();
        System.exit(0);
    }

public String recieveData() {
    String line = "";
    try {
        packet = new DatagramPacket(buffer, buffer.length);
        socket.receive(packet);
        line = new String(packet.getData(), 0, packet.getLength());
        
        // Extract IP header details
        System.out.println("\nReceived packet from server:");
        System.out.println("Source IP Address: " + packet.getAddress().getHostAddress());
        System.out.println("Destination IP Address: " + socket.getLocalAddress().getHostAddress());
        System.out.println("Source Port: " + packet.getPort());
        System.out.println("Destination Port: " + socket.getLocalPort());
        System.out.println("Transport Protocol: UDP");
        System.out.println("Packet Length: " + packet.getLength());
    } catch (IOException ex) {
        log("recieveData: " + ex.toString());
    }
    return line;
}


    public void createAndShowGUI() {
        questionLabel = new JLabel();
        optionButtonA = new JButton("Option A");
        optionButtonB = new JButton("Option B");
        nextButton = new JButton("Next");
        closeButton = new JButton("Close");
        backButton =new JButton("Chat");
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(questionLabel, BorderLayout.NORTH);

        JPanel optionsPanel = new JPanel(new FlowLayout());
        optionsPanel.add(optionButtonA);
        optionsPanel.add(optionButtonB);
        panel.add(optionsPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(nextButton);
        buttonPanel.add(closeButton);
        buttonPanel.add(backButton); 
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
         
    
 

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Personality Quiz");
        setSize(1200, 150);
        setLocationRelativeTo(null);
        setContentPane(panel);
        setVisible(true);
    }
    private void returnToMenuForm() {
    MenuForm1 menuForm = new MenuForm1();
    menuForm.setVisible(true);
    dispose();
}

    public void log(String message) {
        System.out.println(message);
}
}