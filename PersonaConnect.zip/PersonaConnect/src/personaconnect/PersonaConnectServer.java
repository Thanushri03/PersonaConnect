package personaconnect;
import java.io.IOException;
import java.net.*;
import java.util.*;

public class PersonaConnectServer {
    MulticastSocket socket=null;
    byte[] buffer=null;
    DatagramSocket recievePacket=null;
    Scanner scan=null;
    public static void main(String[] args){
        PersonaConnectServer server=new PersonaConnectServer();
        server.initializeVariable();
        server.questions();
        server.receive();
    }
    public void questions(){
        while(true){
        String Question1="Do you prefer to spend time with others or alone?\nOptions:\na) I prefer spending time with others.\nb) I prefer spending time alone.\n";
        String Question2="How do you prefer to gather information?\nOptions:\na) I prefer to focus on concrete facts and details.\nb) I prefer to focus on patterns and possibilities.\n";
        String Question3="How do you typically make decisions?\nOptions:\na) I prefer to make decisions based on logical analysis.\nb) I prefer to make decisions based on personal values and emotions.\n";
        String Question4="How do you approach the outside world?\nOptions:\na) I prefer to have a planned and organized lifestyle.\nb) I prefer to be spontaneous and adaptable.\n";
        send(Question1);
        send(Question2);
        send(Question3);
        send(Question4);
        buffer=new byte[Constants.BUFFER_SIZE];
        }
    }
    public void initializeVariable(){
        try{
            socket=new MulticastSocket();
            buffer = new byte[Constants.BUFFER_SIZE];
            scan =new Scanner(System.in);
           
            log("Server is running...");
        }catch(SocketException ex){
            log("initializeVariable" + ex.toString());
        }
        catch(IOException ex){
            log("initializeVariable" + ex.toString());
        }
    }
   
    private String readFromKeyboard(){
        String line=scan.nextLine();
        return line;
    }
    
    private void send(String message){
        try{
            int checksum = calculateChecksum(message.getBytes());

            // Append the checksum to the message
            String messageWithChecksum = message + "\nChecksum: " + checksum;

            InetAddress ip = InetAddress.getByName(Constants.IP);

            buffer = messageWithChecksum.getBytes();
            DatagramPacket packetSend = new DatagramPacket(buffer, buffer.length, ip, Constants.PORT);
            socket.send(packetSend);
        }catch(IOException ex){
            log("Send:"+ex.toString());
        }
    }
    
    private void log(String message){
        System.out.println(message);
}
  
        public void receive() {
        try {
            recievePacket = new DatagramSocket(Constants.PORT);
            buffer = new byte[Constants.BUFFER_SIZE];
            while (true) {
                DatagramPacket receivePacket = new DatagramPacket(buffer, buffer.length);
                recievePacket.receive(receivePacket);

                // Extract IP header details
                InetAddress clientAddress = receivePacket.getAddress();
                int clientPort = receivePacket.getPort();

                byte[] receiveData = receivePacket.getData();
                int receiveLength = receivePacket.getLength();
                String clientData = new String(receiveData, 0, receiveLength).trim();

                System.out.println("\nReceived packet from client:");
                System.out.println("Source IP Address: " + receivePacket.getAddress().getHostAddress());
                System.out.println("Destination IP Address: " + recievePacket.getLocalAddress().getHostAddress());
                System.out.println("Source Port: " + receivePacket.getPort());
                System.out.println("Destination Port: " + recievePacket.getLocalPort());
                System.out.println("Transport Protocol: UDP");
                System.out.println("Packet Length: " + receivePacket.getLength());
                System.out.println("Checksum: " + (receiveData[receiveLength - 1] & 0xFF));

                // Verify checksum
                boolean checksumMatch = verifyChecksum(receivePacket);
                System.out.println("Checksum verification: " + (checksumMatch ? "Passed" : "Failed"));
            }
        } catch (SocketException ex) {
            log("Receive: " + ex.toString());
        } catch (IOException ex) {
            log("Receive: " + ex.toString());
        }
    }

    private boolean verifyChecksum(DatagramPacket packet) {
        byte[] data = packet.getData();
        int checksum = data[data.length - 1] & 0xFF; // Extract the checksum byte
        data[data.length - 1] = 0; // Clear the checksum byte

        int calculatedChecksum = calculateChecksum(data);

        boolean checksumMatch = calculatedChecksum == checksum;
        return checksumMatch;
    }

    private int calculateChecksum(byte[] data) {
        int checksum = 0;
        for (byte b : data) {
            checksum ^= b & 0xFF; // XOR the byte with the current checksum value
        }
        return checksum;
    }

  
}